# GoogleHackingTool
在线Google Hacking 小工具

![GoogleHackingTool](https://raw.githubusercontent.com/r00tSe7en/pictures/master/googlehacking.gif)

在线版:[GoogleHackingTool](https://ght.se7ensec.cn)

造个轮子，方便自己，方便大家。

2019-1-21 更新了移动端显示错位的bug...

![as](https://starchart.cc/r00tSe7en/GoogleHackingTool.svg)
